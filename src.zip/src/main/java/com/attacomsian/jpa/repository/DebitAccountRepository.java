package com.attacomsian.jpa.repository;



import javax.transaction.Transactional;

import org.springframework.context.annotation.Primary;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.attacomsian.jpa.model.Account;

@Transactional
//@Primary
public interface DebitAccountRepository extends AccountRepository<Account>{

}
