package com.attacomsian.jpa.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.attacomsian.jpa.model.Account;

@NoRepositoryBean
public interface AccountRepository<T extends Account> extends CrudRepository<T, Long>{

}
