package com.attacomsian.jpa.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.attacomsian.jpa.model.Account;

@Transactional
public interface CreditAccountRepository extends AccountRepository<Account>{

}
