package com.attacomsian.jpa.repository;

import javax.transaction.Transactional;

import com.attacomsian.jpa.model.Account;

@Transactional
public interface AccounInfoRepository extends AccountRepository<Account>{

}
