package com.attacomsian.jpa.model;

import java.math.BigDecimal;

import javax.persistence.Entity;

@Entity(name = "CreditAccount")
public class CreditAccount extends Account {

	private BigDecimal creditLimit;

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	

}