package com.attacomsian.jpa.model;

import java.math.BigDecimal;

import javax.persistence.Entity;

import org.springframework.context.annotation.Primary;

@Entity(name = "DebitAccount")

public class DebitAccount extends Account {

	private BigDecimal overdraftFee;

	public BigDecimal getOverdraftFee() {
		return overdraftFee;
	}

	public void setOverdraftFee(BigDecimal overdraftFee) {
		this.overdraftFee = overdraftFee;
	}

	

}