package com.attacomsian.jpa.comtroller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.attacomsian.jpa.model.Account;
import com.attacomsian.jpa.model.CreditAccount;
import com.attacomsian.jpa.model.DebitAccount;
import com.attacomsian.jpa.one2many.domains.Book;
import com.attacomsian.jpa.one2many.repositories.PageRepository;
import com.attacomsian.jpa.repository.AccountRepository;
import com.attacomsian.jpa.repository.DebitAccountRepository;

@RestController
public class JPACotroller {
	
//	@Autowired
//	PageRepository pageRepo;
	
//	@GetMapping(value="/getPage/{page}")
//	public Book getPage(@PathVariable("page") int page) {
//		
//		System.out.println(pageRepo.findById((long) page));
//		
//		return null;
//	}
	
	
	@Autowired
	@Qualifier("creditAccountRepository")
	AccountRepository<Account> repo;

	
	
	@GetMapping(value="/saveAccount")
	public Account getPage() {
		
		CreditAccount account=new CreditAccount();
		
		account.setId((long) 100);
		account.setInterestRate(new BigDecimal("0.04"));
		account.setOwner("Stanley");
		account.setBalance(new BigDecimal("1000000000"));
		account.setCreditLimit(new BigDecimal("10000"));
		
		repo.save(account);
		
		return account;
	}
	

	

}
